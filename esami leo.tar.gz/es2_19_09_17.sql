create index c2 on inserogato(annoaccademico,id_corsostudi);
create index c1 on corsostudi(id);