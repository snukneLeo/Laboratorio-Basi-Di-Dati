#Assumendo di avere una base di dati PostgreSQL che contenga le tabelle di questo tema d’esame, scrive-
#re un programma Python che, leggendo i dati da console, inserisca una o più tuple nella tabella ESERCI-
#ZIO_IN_PROGRAMMA facendo un controllo preventivo che le eventuali dipendenze siano rispettate (si con-
#siderino solo quelle rispetto ad altre tabelle, no ai domini). Se una dipendenza non è rispettata, il programma
#deve richiedere di reinserire il dato associato alla dipendenza prima di procedere a inserire la tupla nella ta-
#bella ESERCIZIO_IN_PROGRAMMA. Il programma deve visualizzare l’esito di ogni singolo inserimento. È
#richiesto che il programma suggerisca il tipo di dati da inserire e che non ammetta possibilità di SQL Injection.