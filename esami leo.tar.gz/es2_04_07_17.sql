create index  i1 on inserogato(annoaccademico,id_corsostudi);


--QUERY DAL PIANO
select *
from inserogato ie
     join insegn i on i.id = ie.id_insegn
where ie.annoaccademico = '2006/2007'
      and id_corsostudi = '4';